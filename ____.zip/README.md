# Application FFT Batch
Socle d&#39;initalisation d&#39;un Batch BDDF

## Introduction
Code IRT : a5318

Trigramme : FFT
