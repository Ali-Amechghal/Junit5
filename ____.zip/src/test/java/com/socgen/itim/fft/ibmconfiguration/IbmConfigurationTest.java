package com.socgen.itim.fft.ibmconfiguration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingMessage;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchema;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import io.swagger.models.Swagger;
import io.swagger.parser.SwaggerParser;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;

public class IbmConfigurationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(IbmConfigurationTest.class);
    public static final String FILE_IBMCONFIGURATION_PATH = "swagger/swagger-def.yaml";
    public static final String NOEUD_IBM_CONFIGURATION = "x-ibm-configuration";

    @Test
    public void validationSchemaIbm() throws IOException, ProcessingException {

        ObjectMapper mapperYaml = new ObjectMapper(new YAMLFactory());
        ObjectMapper mapperJson = new ObjectMapper();
        JsonSchemaFactory factorySchema = JsonSchemaFactory.byDefault();

        JsonSchema schemaIbmConfiguration = factorySchema.getJsonSchema(loadNode ("x-ibm-configuration-schema.json",  mapperJson));

        JsonNode nodeConfig = loadNode (FILE_IBMCONFIGURATION_PATH, mapperYaml);

        Assert.assertNotNull(String.format("Le noeud '%s' n'est pas présent [fichier '%s']", NOEUD_IBM_CONFIGURATION, FILE_IBMCONFIGURATION_PATH), nodeConfig.get(NOEUD_IBM_CONFIGURATION));

        valideSchema(schemaIbmConfiguration, nodeConfig.get(NOEUD_IBM_CONFIGURATION));

    }

    @Test
    public void loadSwagger() {
        Swagger swagger = new SwaggerParser().read(FILE_IBMCONFIGURATION_PATH);

        Object xIbmName = swagger.getInfo() == null ? null : swagger.getInfo().getVendorExtensions().get("x-ibm-name");

        Assert.assertTrue(String.format("Le noeud 'info.x-ibm-name' n'est pas présent ou n'est pas une string non vide [fichier '%s']",
                FILE_IBMCONFIGURATION_PATH), xIbmName != null && xIbmName instanceof String && StringUtils.isNotBlank((String)xIbmName));

        Assert.assertTrue(String.format("Le noeud 'securityDefinitions' doit être présent et non vide [fichier '%s']",
                FILE_IBMCONFIGURATION_PATH), swagger.getSecurityDefinitions() != null && !swagger.getSecurityDefinitions().isEmpty());

        Assert.assertTrue(String.format("Le noeud 'security' doit être présent et non vide [fichier '%s']",
                FILE_IBMCONFIGURATION_PATH), swagger.getSecurity() != null && !swagger.getSecurity().isEmpty());

        Assert.assertTrue(String.format("Le noeud 'path' ne doit pas être renseigné car tout son contenu sera écrasé par" +
                " les informations provenant du scan des annotations swagger [fichier '%s']", FILE_IBMCONFIGURATION_PATH),
                swagger.getPaths() == null || swagger.getPaths().isEmpty());

        Assert.assertTrue(String.format("Le noeud 'definitions' ne doit pas être renseigné car tout son contenu sera écrasé par" +
                        " les informations provenant du scan des annotations swagger [fichier '%s']", FILE_IBMCONFIGURATION_PATH),
                swagger.getDefinitions() == null || swagger.getDefinitions().isEmpty());

    }



    private void valideSchema(JsonSchema schema, JsonNode nodeTovalidate) throws ProcessingException {
        ProcessingReport report = schema.validate(nodeTovalidate);

        if (!report.isSuccess()) {
            for (ProcessingMessage processingMessage : report) {
                LOGGER.error(processingMessage.toString());
            }
            Assert.fail("Le schema Ibm Configuration n'est pas validé");
        }
    }


    private JsonNode loadNode (String ressourceClasspath, ObjectMapper objectMapper) throws IOException {
        JsonNode myNode;
        InputStream in = IbmConfigurationTest.class.getClassLoader().getResourceAsStream(ressourceClasspath);
        try{
            myNode = objectMapper.readTree(in);
        }
        finally{
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return myNode;
    }


}
