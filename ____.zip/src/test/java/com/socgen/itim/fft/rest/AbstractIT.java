package com.socgen.itim.fft.rest;

import com.socgen.dga.idp.jaxrs.SgSignIn;
import com.socgen.dga.idp.server.SgSignInMock;
import com.socgen.dga.idp.server.SgSignInMockServer;
import com.socgen.dga.idp.server.model.Role;
import com.socgen.dga.idp.server.model.SgUser;
import com.socgen.itim.fft.Application;
import io.restassured.RestAssured;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

import com.socgen.itim.fft.integration.rest.SampleService;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;


@SpringBootTest(classes = Application.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("testint")
public abstract class AbstractIT {

    /**
     * LOGGER.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractIT.class);


    @Value("${spring.jersey.application-path:/}")
    private String apiPath;

    @Value("${server.ssl.enabled:/}")
    private Boolean sslEnabled;


    @MockBean
    protected SampleService sampleService;

    /**
     * Port aléatoire pour test.
     */
    @LocalServerPort
    private int port;


    protected static final String CLIENT_ID_DE_BASE = "0000";
    protected static final SgUser SG_USER_DE_BASE = new SgUser("A000001", "Marc", "De Base", "basic@sg.com",
            "0000", "ITIM/ASI/SDC/SDA", Collections.emptyMap());
    protected static final String BEARER_DE_BASE = "bearer 0000";

    protected static AtomicLong SEQUENCE  = new AtomicLong(1L);

    protected static SgSignInMockServer sgSignInMockServer;

    @Inject
    protected SgSignIn sgSignIn;

    @BeforeClass
    public static void startSgSignInMockServer() throws Exception {
        if (sgSignInMockServer == null) {
            sgSignInMockServer = new SgSignInMockServer();
        }
        else {
            sgSignInMockServer.stop();
        }
        sgSignInMockServer.start();
        System.setProperty("app.sg-sign-in.serverUrl", sgSignInMockServer.getServerUrl());
    }

    @AfterClass
    public static void stopSgSignInMockServer() throws Exception {
        if (sgSignInMockServer != null) {
            sgSignInMockServer.stop();
        }
    }

    protected String genereToken(){
        return String.format("Bearer %04d", SEQUENCE.getAndIncrement());
    }

    @Before
    public void setupAbstract() {

        // Ici, Mockito pour initialiser les mocks déclarés, restTemplate, ainsi que base : l'url à tester.
         MockitoAnnotations.initMocks(this);


        // L'url a pu changer depuis la dernière fois par un stop/start
        sgSignIn.setServerURL(sgSignInMockServer.getServerUrl());

        RestAssured.baseURI = sgSignInMockServer.getProxyUrl();
        RestAssured.basePath = apiPath;
        RestAssured.useRelaxedHTTPSValidation();

        setUserDeBase();
    }

    /**
     * Logger pour analyse des log.
     */
    @Rule
    public TestRule watcher = new TestWatcher() {
        protected void starting(final Description description) {
            LOGGER.debug("Starting test: " + description.getClassName() + " - " + description.getMethodName());
        }
    };

    protected void setUserMock(String bearer, SgUser sgUser, String clientId) {
        sgSignIn.setClientId(clientId);
        sgSignInMockServer.ssopProxyMock((Boolean.TRUE.equals(sslEnabled)?"https":"http")+"://localhost:" + port,
                RestAssured.basePath,
                SgSignInMock.forClientId(clientId)
                        .andAccessToken(bearer)
                        .thenReturnSgUser(sgUser));

    }


    protected void setUserDeBase() {
        setUserMock(BEARER_DE_BASE, SG_USER_DE_BASE, CLIENT_ID_DE_BASE);
    }

    protected String setCustomUserWithRoles(String... roles) {

        Map<String, List<Role>> customRoles = buildMapRole(roles);

        SgUser customUser =
                new SgUser(SG_USER_DE_BASE.getUserId(),
                        SG_USER_DE_BASE.getFirstName(),
                        SG_USER_DE_BASE.getLastName(),
                        SG_USER_DE_BASE.getEmail(),
                        SG_USER_DE_BASE.getPhone(),
                        SG_USER_DE_BASE.getServiceName(),
                        customRoles);

        return setCustomUser(customUser);
    }

    protected String setCustomUser(SgUser customUser) {

        String token = genereToken();
        setUserMock(token, customUser, CLIENT_ID_DE_BASE);
        return token;
    }


    protected Map<String, List<Role>> buildMapRole(String... roleNames){
        Map<String, List<Role>> mapRole = new HashMap<>();
        List<Role> listRole = new ArrayList<>();
        for (String roleName : roleNames) {
            Role role = new Role();
            role.setName(roleName);
            listRole.add(role);
        }
        mapRole.put(sgSignIn.getTrigram(), listRole);
        return mapRole;
    }


}
