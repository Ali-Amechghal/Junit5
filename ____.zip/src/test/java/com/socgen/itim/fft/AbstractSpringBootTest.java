package com.socgen.itim.fft;

import com.socgen.itim.fft.util.TestConfigurationComplement;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * Permet de lancer les tests avec un context Spring de test,
 * La classe de test doit étendre celle-ci et ajouter :
 * "@RunWith(SpringRunner.class)"
 * "@Transactional"
 * Note : ne convient pas pour des tests d'integration (utiliser AbstractIT)
 */
@SpringBootTest(classes = {TestConfigurationComplement.class, Application.class})
@ActiveProfiles("test")
public class AbstractSpringBootTest {

}
