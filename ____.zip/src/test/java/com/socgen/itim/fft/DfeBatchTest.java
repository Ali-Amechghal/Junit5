package com.socgen.itim.fft;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author X174886
 * Test d'intégration du batch
 */
@SpringBootTest(classes = Application.class)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = TestBatchConfigurationIT.class)
@TestPropertySource(properties = {"spring.cloud.task.closecontext_enable=false"})
@ActiveProfiles("testint")
public class DfeBatchTest {

  private static final String COMPLETED = "COMPLETED";

  @Autowired
  private JobLauncherTestUtils jobLauncherTestUtils;

  @Test
  public void should_verfiy_job_execution() throws Exception {
    JobExecution jobExecution = jobLauncherTestUtils.launchJob();
    Assert.assertEquals(COMPLETED, jobExecution.getExitStatus().getExitCode());
  }
}
