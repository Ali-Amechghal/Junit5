package com.socgen.itim.fft.repository;

import com.socgen.itim.fft.AbstractSpringBootTest;
import com.socgen.itim.fft.domain.Article;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Exemple de test unitaire avec le context Spring de test
 */
@RunWith(SpringRunner.class)
@Transactional
// Si le fichier changelog-test01.xml est commun à tous les tests, on peut directement renseigner spring.liquibase.changeLog
// dans application-test.yml (et retirer liquibase.drop-first:true, ca gagnera en perf)
@TestPropertySource(
        properties = {
                "spring.liquibase.changeLog=classpath:/db/changelog/test/changelog-test-load-datas-01.xml"
        }
)
public class ArticleRepositoryTest extends AbstractSpringBootTest {

    @Autowired
    private ArticleRepository articleRepository;


    @Test
    public void findByTitleA(){
        List<Article> listArticleA = articleRepository.findByTitle("ArticleTestA");

        Assert.assertTrue(listArticleA.size() > 0);
    }
}
