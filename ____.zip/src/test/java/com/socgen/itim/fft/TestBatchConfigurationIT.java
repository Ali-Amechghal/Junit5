package com.socgen.itim.fft;


import com.socgen.itim.fft.domain.CrmDfe01;
import com.socgen.itim.fft.dto.dfe.CrmDfeHeader;
import com.socgen.itim.fft.processor.CrmDfeDataLineProcessor;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@EnableBatchProcessing
@ComponentScan("com.socgen.itim.fft")
@Configuration
@Profile("testint")
public class TestBatchConfigurationIT {

    @Bean
    JobLauncherTestUtils jobLauncherTestUtils() {
        return new JobLauncherTestUtils();
    }

    @Bean
    public ItemProcessor processor() {
        return new CrmDfeDataLineProcessor() {
            @Override
            public CrmDfe01 process(CrmDfeHeader tiersRemedie) {
                final CrmDfe01 process = super.process(tiersRemedie);
                if (process != null && process.getIdTiers().equals("UFG8521")) {
                    process.setMessage("OK");
                }
                return process;
            }
        };
    }
}
