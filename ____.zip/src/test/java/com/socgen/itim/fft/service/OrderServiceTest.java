package com.socgen.itim.fft.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.dga.idp.server.model.SgUser;
import com.socgen.itim.fft.domain.Article;
import com.socgen.itim.fft.dto.OrderDTO;
import com.socgen.itim.fft.dto.OrderLineDTO;
import com.socgen.itim.fft.repository.ArticleRepository;
import org.assertj.core.data.Offset;
import org.junit.Before;
import org.junit.Test;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

public class OrderServiceTest {
    public static final BigDecimal MARGE_ERROR = new BigDecimal("0.01");


    @InjectMocks
    private OrderService orderService = new OrderService(null);



    @Mock
    private ArticleRepository mockArticleRepository;

    @Before
    public void setUp(){
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void simulateMontantCommande(){

        BigDecimal prixUntaire = new BigDecimal("150.00");

        when(mockArticleRepository.findById(any(Long.class)))
                .thenReturn(Optional.of(new Article().price(prixUntaire)));

        int nb = 5;
        BigDecimal montant =  orderService.simulateMontantCommande(1L, nb);

        assertThat(montant).isCloseTo(prixUntaire.multiply(BigDecimal.valueOf(nb)), Offset.offset(MARGE_ERROR));

    }


    @Test
    public void passerOrder() throws JsonProcessingException {

        BigDecimal prixUntaire1 = new BigDecimal("150.00");
        BigDecimal prixUntaire2 = new BigDecimal("30.00");

        String userId = "A000000";
        int nb1 = 7;
        int nb2 = 10;

        List<OrderLineDTO> lines = new ArrayList<>();
        lines.add(new OrderLineDTO().idArticle(1L).nb(nb1));
        lines.add(new OrderLineDTO().idArticle(2L).nb(nb2));

        SgUser mySguser = new SgUser();
        mySguser.setUserId(userId);
        SgUserPrincipal sgUserPrincipal = new SgUserPrincipal(new ObjectMapper().writeValueAsString(mySguser));

        Article article1 = new Article().id(1L).price(prixUntaire1);
        Article article2 = new Article().id(2L).price(prixUntaire2);
        List<Article> listArticle = new ArrayList<>();
        listArticle.add(article1);
        listArticle.add(article2);

        when(mockArticleRepository.findAllById((Iterable) any()))
                .thenReturn(listArticle);

        OrderDTO order = orderService.passerOrder(lines, sgUserPrincipal);

        assertThat(order.getMontantTotal()).isCloseTo(
                BigDecimal.valueOf(prixUntaire1.doubleValue() * nb1 + prixUntaire2.doubleValue() * nb2),
                Offset.offset(MARGE_ERROR));

        assertThat(order.getCustomer()).endsWith(userId);
        assertThat(order.getDate()).isNotNull();
        assertThat(order.getLines()).hasSameSizeAs(lines);
    }
}
