package com.socgen.itim.fft.util;

import org.springframework.context.annotation.Configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.data.domain.AuditorAware;

import java.util.Optional;

/**
 * Classe permettant une surcharge de certains éléments de configuration
 */
@Configuration
public class TestConfigurationComplement {

    @Bean("customAuditorAware")
    @Primary
    public AuditorAware<String> getCustomAuditorAwareMock () {
        return () -> Optional.of("testU-user");
    }
}
