package com.socgen.itim.fft.repository;

import com.socgen.itim.fft.domain.Article;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ArticleRepository extends JpaRepository<Article, Long> {

    /**
     * Juste un exemple de Spring Data
     */
    List<Article> findByTitle(String title);

}

