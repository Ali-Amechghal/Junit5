package com.socgen.itim.fft.processor;

import org.springframework.batch.core.step.skip.SkipLimitExceededException;
import org.springframework.batch.core.step.skip.SkipPolicy;

/**
 * @author X174886
 *
 * ignorer toutes les exceptions sans limite
 */
public class SkipPolicyProcessor implements SkipPolicy {


  @Override
  public boolean shouldSkip(Throwable throwable, int i) throws SkipLimitExceededException {
    return true;
  }
}
