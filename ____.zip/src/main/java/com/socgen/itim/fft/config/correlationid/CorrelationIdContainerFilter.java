package com.socgen.itim.fft.config.correlationid;

import javax.annotation.Priority;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import java.io.IOException;
import java.util.List;


@Priority(CorrelationIdContainerFilter.PRIORITY_CORRELATION_ID)
public class CorrelationIdContainerFilter implements ContainerRequestFilter, ContainerResponseFilter {

    public static final int PRIORITY_CORRELATION_ID = -11000;

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        String originalGlobalTransactionId = requestContext.getHeaderString(CorrelationIdUtils.HEADER_CORRELATION_ID);
        String globalTransactionId = CorrelationIdUtils.addOrCreateCorrelationId(originalGlobalTransactionId);

        // On met quoiqu'il arrive le globalTransactionId qu'on va vraiment utiliser
        if (originalGlobalTransactionId == null) {
            requestContext.getHeaders().add(CorrelationIdUtils.HEADER_CORRELATION_ID, globalTransactionId);
        }
        else {
            List<String> listValue =  requestContext.getHeaders().get(CorrelationIdUtils.HEADER_CORRELATION_ID);
            listValue.clear();
            listValue.add(globalTransactionId);
        }
    }

    @Override
    public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext) throws IOException {
        String correlationID = CorrelationIdUtils.getCorrelationId();
        CorrelationIdUtils.removeCorrelationId();
        // On ajoute dans le header
        if (correlationID != null) {
            responseContext.getHeaders().add(CorrelationIdUtils.HEADER_CORRELATION_ID, correlationID);
        }
    }
}
