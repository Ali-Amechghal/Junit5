package com.socgen.itim.fft.service;

import com.codahale.metrics.annotation.Timed;
import com.socgen.itim.fft.domain.Article;
import com.socgen.itim.fft.integration.rest.SampleService;
import com.socgen.itim.fft.repository.ArticleRepository;
import com.socgen.itim.fft.rest.sample.models.Sample;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import javax.ws.rs.NotFoundException;
import java.math.BigDecimal;
import java.util.Optional;

@Service
public class ArticleService {


    private ArticleRepository articleRepository;


    private SampleService sampleService;


    public ArticleService(ArticleRepository articleRepository, SampleService sampleService) {
        this.articleRepository = articleRepository;
        this.sampleService = sampleService;
    }


    /**
     * Service exemple qui appel un service tiers (sampleService)
     */
    @Timed
    public BigDecimal appelExempleCallTiers(Long id) {
        Optional<Sample> sampleUnique = sampleService.getSampleParId(id);
        if (sampleUnique.isPresent()) {
            // On prends le prix du sample et on ajoute une marge de 10
            return sampleUnique.get().getPrice();
        } else {
            throw new NotFoundException();
        }
    }


    /**
     * Double et persiste le prix d'un article
     */
    @Transactional
    public Article doublerPrix(Long articleId) {
        Optional<Article> myArticleOptional = articleRepository.findById(articleId);

        if (!myArticleOptional.isPresent()) {
            throw new NotFoundException();
        }

        Article myArticle = myArticleOptional.get();
        if (myArticle.getPrice() == null) {
            myArticle.setPrice(BigDecimal.ONE);
        } else {
            myArticle.setPrice(myArticle.getPrice().multiply(new BigDecimal("2")));
        }

        return myArticle;
    }

}
