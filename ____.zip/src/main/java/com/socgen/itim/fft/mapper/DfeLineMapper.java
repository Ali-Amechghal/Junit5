package com.socgen.itim.fft.mapper;

import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.file.transform.PatternMatchingCompositeLineTokenizer;

/**
 * @author X174886
 * <p>
 * Mapper une ligne d'un fichier DFE
 * <p>
 * Preparer les tokenizers qui matchent chaque ligne
 */
public class DfeLineMapper<T> extends DefaultLineMapper<T> {

    private PatternMatchingCompositeLineTokenizer dfePatternMatchingLineTokenizer;

    private CrmDfeFieldSetMapper dfeFieldSetMapper;

    @Override
    public void setLineTokenizer(LineTokenizer tokenizer) {
        super.setLineTokenizer(tokenizer);
        if (tokenizer instanceof PatternMatchingCompositeLineTokenizer) {
            this.dfePatternMatchingLineTokenizer = (PatternMatchingCompositeLineTokenizer) tokenizer;
        } else {
            throw new IllegalArgumentException(
                    "lineMapper must be a class or subclass of " + PatternMatchingCompositeLineTokenizer.class.getName());
        }
    }

    @Override
    public void setFieldSetMapper(FieldSetMapper<T> fieldSetMapper) {
        super.setFieldSetMapper(fieldSetMapper);
        if (fieldSetMapper instanceof FieldSetMapper) {
            this.dfeFieldSetMapper = (CrmDfeFieldSetMapper) fieldSetMapper;
        } else {
            throw new IllegalArgumentException("lineMapper must be a class or subclass of " + FieldSetMapper.class.getName());
        }
    }
}
