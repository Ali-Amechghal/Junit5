package com.socgen.itim.fft.config;

import com.socgen.dga.idp.jaxrs.DefaultSgSignIn;
import com.socgen.dga.idp.jaxrs.SgSignIn;
import com.socgen.dga.idp.jaxrs.commons.ConfigKey;
import com.socgen.dga.idp.jaxrs.commons.monitoring.SgSigninLogFormat;
import com.socgen.dga.idp.jaxrs.commons.monitoring.Slf4jSgSigninListener;
import com.socgen.dga.idp.jaxrs.commons.utils.CacheProvider;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.cache.Cache;

@Configuration("sgSignInConfig")
public class SgSignInConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(SgSignInConfig.class);

    @Autowired
    private ApplicationProperties applicationProperties;

    private CacheProvider cacheProviderSgSigin;
    private Cache<String, String> sgSignInCache;


    @PostConstruct
    public void initCache()  {
        cacheProviderSgSigin = new CacheProvider();
        sgSignInCache = cacheProviderSgSigin.createCache();
    }

    @Bean(name = ConfigKey.SG_SIGNIN_BEAN_NAME)
    public SgSignIn getSgSignInInstance()
    {
        //============================
        // Mandatory config
        //===========================
        SgSignIn sgSignIn = new DefaultSgSignIn();
        if (applicationProperties.getSgSignIn() != null) {
            sgSignIn.setClientId(applicationProperties.getSgSignIn().getClientId());
            sgSignIn.setClientSecret(applicationProperties.getSgSignIn().getClientSecret());
            sgSignIn.setServerURL(applicationProperties.getSgSignIn().getServerUrl());
            if (applicationProperties.getSgSignIn().isEnableCors()) {
                sgSignIn.enableCORS(applicationProperties.getSgSignIn().getCorsDomain());
            }
            sgSignIn.setTrigram(applicationProperties.getTrigram());
            sgSignIn.setOAuth2RedirectUrl(StringUtils.trimToEmpty(applicationProperties.getSgSignIn().getRedirectUrl()));
            if(applicationProperties.getSgSignIn().isAcceptOnlyRequestsFromSSOP()) {
                sgSignIn.acceptOnlyRequestsFromSSOP();
            }

        }
        else {
            LOGGER.warn("Aucune configuration SgSignIn trouvée.");
        }

        // Pour logger les events sg sigin au format json
        sgSignIn.subscribeLogEventListener(new Slf4jSgSigninListener()
                .format(SgSigninLogFormat.JSON));

        return sgSignIn;
    }

    @Bean(name = ConfigKey.SG_SIGNIN_CACHE_BEAN_NAME)
    public javax.cache.Cache<String, String>  getSgSignInCacheInstance()
    {
        return sgSignInCache;
    }

    @PreDestroy
    public void destroyCache()
    {
        if (cacheProviderSgSigin != null) {
            cacheProviderSgSigin.clearCache();
        }

    }
}
