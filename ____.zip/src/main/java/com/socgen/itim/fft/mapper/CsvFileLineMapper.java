package com.socgen.itim.fft.mapper;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.socgen.itim.fft.dto.SampleCsvFile;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.AbstractLineTokenizer;
import org.springframework.batch.item.file.transform.DefaultFieldSetFactory;
import org.springframework.batch.item.file.transform.LineTokenizer;

/**
 * @author X174886
 *
 * @param <T>
 */
public class CsvFileLineMapper<T> extends DefaultLineMapper<T> {

  private AbstractLineTokenizer tokenizer;

  public void setNames() {
    tokenizer.setNames(getFields());
  }

  @Override
  public void setLineTokenizer(LineTokenizer tokenizer) {
    super.setLineTokenizer(tokenizer);
    if (tokenizer instanceof AbstractLineTokenizer) {
      this.tokenizer = (AbstractLineTokenizer) tokenizer;
    } else {
      throw new IllegalArgumentException("lineMapper must be a class or subclass of "
          + CsvFileLineMapper.class.getName());
    }
  }

  @Override
  public void afterPropertiesSet() {
    super.afterPropertiesSet();
    DefaultFieldSetFactory fsf = new DefaultFieldSetFactory();

    tokenizer.setFieldSetFactory(fsf);
  }

  /**
   * Returner la liste des attributs d'une classe
   * @return
   */
  private static String[] getFields() {
    Class<? extends SampleCsvFile> componentClass = SampleCsvFile.class;
    Field[] fields = componentClass.getDeclaredFields();
    List<String> lines = new ArrayList<>(fields.length);

    Arrays.stream(fields)
        .forEach(field -> addField(lines, field));

    return lines.toArray(new String[lines.size()]);
  }

  /**
   *
   * @param lines
   * @param field
   */
  private static void addField(List<String> lines, Field field) {
    if (field.isSynthetic()) {
      return;
    }
    field.setAccessible(true);
    lines.add(field.getName());
  }
}
