package com.socgen.itim.fft.reader;

import com.socgen.itim.fft.mapper.CsvFileLineMapper;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineCallbackHandler;
import org.springframework.batch.item.file.LineMapper;

/**
 * @author X174886
 * @param <T>
 *
 *  Un reader de fichiers CSV
 */
public class CsvFileReader<T> extends FlatFileItemReader<T> {

  private CsvFileLineMapper<T> lineMapper;

  @Override
  public void afterPropertiesSet() throws Exception {
    super.afterPropertiesSet();
    setLinesToSkip(1);
    setSkippedLinesCallback(new FieldNameLineCallback());
  }

  @Override
  public void setLineMapper(LineMapper<T> lineMapper) {
    super.setLineMapper(lineMapper);
    if (lineMapper instanceof CsvFileLineMapper) {
      this.lineMapper = (CsvFileLineMapper<T>) lineMapper;
    } else {
      throw new IllegalArgumentException("lineMapper must be a class or subclass of "
          + CsvFileLineMapper.class.getName());
    }
  }

  class FieldNameLineCallback implements LineCallbackHandler {
    @Override
    public void handleLine(String line) {
      lineMapper.setNames();
    }
  }

}
