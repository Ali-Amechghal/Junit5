package com.socgen.itim.fft.domain;

import com.socgen.itim.fft.domain.common.AbstractEntity;
import lombok.Builder;
import lombok.Data;

/**
 * @author X174886
 * <p>
 * Le modèle de retour suite à un traitement batch
 * <p>
 * A écrire dans une base de données ou dans un fichier
 */
@Data
public class CrmDfe01 extends AbstractEntity {

    private String idTiers;

    private String message;

    @Builder
    public CrmDfe01(String idTiers, String message) {
        this.idTiers = idTiers;
        this.message = message;
    }

    public String getIdTiers() {
        return idTiers;
    }

    public void setIdTiers(String idTiers) {
        this.idTiers = idTiers;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
