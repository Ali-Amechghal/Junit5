package com.socgen.itim.fft.mapper;

import com.socgen.itim.fft.dto.dfe.CrmDfeHeader;
import com.socgen.itim.fft.enumeration.CrmDfeEnum;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.Range;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author X174886
 * <p>
 * Tokenizer chaque remontée DFE
 * <p>
 * 1- Préparer la liste des attributs à matcher
 * 2- Spécifier les intervalles d'extraction dans la ligne DFE
 */
public class DfeLineTokenizer {

    private FixedLengthTokenizer fixedLengthTokenizer;

    public FixedLengthTokenizer tokenizeDfeLine(String idCrm, List<Integer> rangesList) {
        fixedLengthTokenizer = new FixedLengthTokenizer();
        fixedLengthTokenizer.setNames(getFields(idCrm));
        fixedLengthTokenizer.setColumns(getColumns(rangesList));
        return fixedLengthTokenizer;
    }

    /**
     * Extraire la liste des champs de chaque classe DTO DFE
     *
     * @param idCrm  exmeple; IBT01
     * @return
     */
    private String[] getFields(String idCrm) {
        Class<?> clazz = CrmDfeEnum.getClass(idCrm, true);
        List<String> fields = new ArrayList<>();
        //get crm header fields
        Arrays.stream(CrmDfeHeader.class.getDeclaredFields()).forEach(field -> addField(fields, field));
        //get crm class fields
        Arrays.stream(clazz.getDeclaredFields()).forEach(field -> addField(fields, field));
        return fields.toArray(new String[fields.size()]);
    }

    private static void addField(List<String> lines, Field field) {
        if (field.isSynthetic()) {
            return;
        }
        field.setAccessible(true);
        lines.add(lines.size(), field.getName());
    }

    /**
     * Préparer les intervalles d'extraction des données
     *
     * @param rangesList
     * @return
     */
    private Range[] getColumns(List<Integer> rangesList) {
        List<Range> columns = new ArrayList<>(rangesList.size());
        Integer sup = 1;
        Integer inf;

        for (Integer range : rangesList) {
            inf = sup;
            sup = sup + range;
            columns.add(new Range(inf, sup - 1));
        }
        return columns.toArray(new Range[columns.size()]);
    }
}
