package com.socgen.itim.fft.reader;

import com.socgen.itim.fft.mapper.DfeLineMapper;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;

/**
 * @author X174886
 *
 * Un reader de fichiers DFE
 * @param <T>
 */
public class DfeFileReader<T> extends FlatFileItemReader<T> {

  /**
   * Mapper la ligne DFE
   */
  private DfeLineMapper<T> dfeLineMapper;

  @Override
  public void afterPropertiesSet() throws Exception {
    super.afterPropertiesSet();
  }

  @Override
  public void setLineMapper(LineMapper<T> lineMapper) {
    super.setLineMapper(lineMapper);
    if (lineMapper instanceof DfeLineMapper) {
      this.dfeLineMapper = (DfeLineMapper<T>) lineMapper;
    } else {
      throw new IllegalArgumentException("lineMapper must be a class or subclass of " + DfeLineMapper.class.getName());
    }
  }
}
