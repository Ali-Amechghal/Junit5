package com.socgen.itim.fft.writer;

import com.socgen.itim.fft.domain.CrmDfe01;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.FieldExtractor;
import org.springframework.batch.item.file.transform.LineAggregator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/**
 * @author X174886
 * <p>
 * Ecriture dans un fichier texte
 */
@Configuration
public class FlatFileWriter {

    @Bean(name = "fileWriter")
    ItemWriter<CrmDfe01> itemWriter(@Value("${output}") Resource resource) {
        FlatFileItemWriter<CrmDfe01> outputFileWriter = new FlatFileItemWriter<>();
        LineAggregator<CrmDfe01> lineAggregator = createCrmTiersResultLineAggregator();
        outputFileWriter.setLineAggregator(lineAggregator);
        outputFileWriter.setLineSeparator(StringUtils.LF);
        outputFileWriter.setAppendAllowed(true);
        outputFileWriter.setResource(resource.exists() ? resource : new ClassPathResource(resource.getFilename()));
        return outputFileWriter;
    }

    /**
     * Construction d'une chaine de caractères à partir d'un objet
     */
    private LineAggregator<CrmDfe01> createCrmTiersResultLineAggregator() {
        DelimitedLineAggregator<CrmDfe01> lineAggregator = new DelimitedLineAggregator<>();
        lineAggregator.setDelimiter("");
        FieldExtractor<CrmDfe01> fieldExtractor = createCrmTiersResultFieldExtractor();
        lineAggregator.setFieldExtractor(fieldExtractor);

        return lineAggregator;
    }

    /**
     * Définir la structure de la chaine de caractère qui sera convertie à partir d'un objet
     */
    private FieldExtractor<CrmDfe01> createCrmTiersResultFieldExtractor() {
        BeanWrapperFieldExtractor<CrmDfe01> extractor = new BeanWrapperFieldExtractor<>();
        extractor.setNames(new String[]{"idCrm", "natuTierEmd"});
        return extractor;
    }
}
