package com.socgen.itim.fft.config.ssl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

public class SSLHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(SSLHelper.class);

    private static final X509Certificate[] EMPTY_ARRAY_X509_CERTIFICATE = new X509Certificate[0];

    public static SSLContext getMockSSLContextForDev() {
        SSLContext sc = null;
        TrustManager[] trustManagers = new TrustManager[]{new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {

            }

            @Override
            public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {

            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return EMPTY_ARRAY_X509_CERTIFICATE;
            }
        }};
        try {
            sc = SSLContext.getInstance("SSL");
            sc.init(null, trustManagers, new java.security.SecureRandom());
        } catch (NoSuchAlgorithmException | KeyManagementException e) {
            LOGGER.error("Erreur", e);
        }
        return sc;
    }
}
