package com.socgen.itim.fft.dto.dfe;

import lombok.Data;
import lombok.ToString;

/**
 * @author X174886
 *
 * L'entête des fichiers DFE - la meme pour tous les flux DFE
 *
 * Structure inchangeable
 */
@Data
@ToString
public class CrmDfeHeader {

  /**
   * Identifiant CRM X(06)
   */
  private String idCrm;

  /**
   * Code Action X(01)
   */
  private String etat;

  /**
   * Longueur du flux X(04)
   */
  private String lgCrm;

  /**
   * Date de traitement DFE X(08)
   */
  private String dateTrt;

  /**
   * Numéro de vacation X(02)
   */
  private String numVac;

  /**
   * Numéro d'abonnement X(05)
   */
  private String numAbonnement;

  /**
   * Clé du CRM X(90)
   */
  private String indocmj;

  /**
   * Date et heure mise à jour GRC X(20)
   */
  private String heureModif;

  /**
   * Identifiant Tiers X(07)
   */
  private String idTiers;


  public CrmDfeHeader(String idCrm, String etat, String lgCrm, String dateTrt, String numVac,
      String numAbonnement, String indocmj, String heureModif, String idTiers) {
    this.idCrm = idCrm;
    this.etat = etat;
    this.lgCrm = lgCrm;
    this.dateTrt = dateTrt;
    this.numVac = numVac;
    this.numAbonnement = numAbonnement;
    this.indocmj = indocmj;
    this.heureModif = heureModif;
    this.idTiers = idTiers;
  }
}
