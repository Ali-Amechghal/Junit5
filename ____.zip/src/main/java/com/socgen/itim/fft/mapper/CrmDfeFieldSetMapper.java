package com.socgen.itim.fft.mapper;

import com.socgen.itim.fft.dto.dfe.CrmDfeHeader;
import com.socgen.itim.fft.enumeration.CrmDfeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @author X174886
 * <p>
 * Un fieldSet Mapper pour Dfe
 */
public class CrmDfeFieldSetMapper implements FieldSetMapper<CrmDfeHeader> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CrmDfeFieldSetMapper.class);

    @Override
    public CrmDfeHeader mapFieldSet(FieldSet fieldSet) {
        String idCrm = fieldSet.readString(0);
        Class cls = CrmDfeEnum.getClass(idCrm, false);

        try {
            Method method = cls.getDeclaredMethod("mapCrm", FieldSet.class);
            return (CrmDfeHeader) method.invoke(fieldSet, fieldSet);
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException ex) {
            LOGGER.error("Enable to map filedSet");
        }
        return null;
    }
}
