package com.socgen.itim.fft.dto.dfe;


import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.batch.item.file.transform.FieldSet;

/**
 * @author X174886
 *
 * Les données spécifiques à chaque remontée DFE
 *
 * Ceci est un exemple pour CRM - 01
 */
@Getter
@Setter
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class SampleCrmDfe01 extends CrmDfeHeader {

  /**
   * NATU_TIER de l’EMD X(01)
   */
  private String natuTierEmd;

  /**
   * Top banque privée avant X(03)
   */
  private String xBanquePrivAvant;

  /**
   * Top banque privée après X(03)
   */
  private String xBanquePrivApres;

  /**
   * Indicateur PPE avant X(01)
   */
  private String xIndPpeAvant;

  /**
   * Indicateur PPE après X(01)
   */
  private String xIndppeApres;

  /**dd
   * Top Nouvelles Négatives avant X(01)
   */
  private

  String xNouvellesNegAvant;

  /**
   * Top NOuvelles Négatives après X(01)
   */
  private String xNouvellesNegApres;

  /**
   * Top embargo Pays avant X(01)
   */
  private String xTopEmbargoPaysAvant;

  /**
   * Top embargo Pays après X(01)
   */
  private String xTopEmbargoPaysApres;

  /**
   * Top Embargo Personne avant X(01)
   */
  private String xTopEmbargoPersAvant;

  /**
   * Top Embargo Personne après X(01)
   */
  private String xTopEmbargoPersApres;

  @Builder
  public SampleCrmDfe01(String idCrm, String etat, String lgCrm, String dateTrt, String numVac,
      String numAbonnement, String indocmj, String heureModif, String idTiers, String natuTierEmd,
      String xBanquePrivAvant, String xBanquePrivApres, String xIndPpeAvant, String xIndppeApres,
      String xNouvellesNegAvant, String xNouvellesNegApres, String xTopEmbargoPaysAvant,
      String xTopEmbargoPaysApres, String xTopEmbargoPersAvant, String xTopEmbargoPersApres) {
    super(idCrm, etat, lgCrm, dateTrt, numVac, numAbonnement, indocmj, heureModif, idTiers);
    this.natuTierEmd = natuTierEmd;
    this.xBanquePrivAvant = xBanquePrivAvant;
    this.xBanquePrivApres = xBanquePrivApres;
    this.xIndPpeAvant = xIndPpeAvant;
    this.xIndppeApres = xIndppeApres;
    this.xNouvellesNegAvant = xNouvellesNegAvant;
    this.xNouvellesNegApres = xNouvellesNegApres;
    this.xTopEmbargoPaysAvant = xTopEmbargoPaysAvant;
    this.xTopEmbargoPaysApres = xTopEmbargoPaysApres;
    this.xTopEmbargoPersAvant = xTopEmbargoPersAvant;
    this.xTopEmbargoPersApres = xTopEmbargoPersApres;
  }


  /**
   * Construire un objet IBFT01 à partir du mapping spring de la ligne
   * @param fieldSet
   * @return
   */
  public static CrmDfeHeader mapCrm(FieldSet fieldSet) {
    return SampleCrmDfe01.builder()
        .idCrm(fieldSet.readString(0))
        .etat(fieldSet.readString(1))
        .lgCrm(fieldSet.readString(2))
        .dateTrt(fieldSet.readString(3))
        .numVac(fieldSet.readString(4))
        .numAbonnement(fieldSet.readString(5))
        .indocmj(fieldSet.readString(6))
        .heureModif(fieldSet.readString(7))
        .idTiers(fieldSet.readString(8))
        .natuTierEmd(fieldSet.readString(9))
        .xBanquePrivAvant(fieldSet.readString(10))
        .xBanquePrivApres(fieldSet.readString(11))
        .xIndPpeAvant(fieldSet.readString(12))
        .xIndppeApres(fieldSet.readString(13))
        .xNouvellesNegAvant(fieldSet.readString(14))
        .xNouvellesNegApres(fieldSet.readString(15))
        .xTopEmbargoPaysAvant(fieldSet.readString(16))
        .xTopEmbargoPaysApres(fieldSet.readString(17))
        .xTopEmbargoPersAvant(fieldSet.readString(18))
        .xTopEmbargoPersApres(fieldSet.readString(19))
        .build();
  }
}
