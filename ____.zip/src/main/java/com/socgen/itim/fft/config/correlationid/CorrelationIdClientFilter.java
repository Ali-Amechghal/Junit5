package com.socgen.itim.fft.config.correlationid;

import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import java.io.IOException;

@Priority(Priorities.USER)
public class CorrelationIdClientFilter implements ClientRequestFilter {

    @Override
    public void filter(ClientRequestContext ctx) throws IOException {
        String correlationId = CorrelationIdUtils.getCorrelationId();

        if (correlationId != null && correlationId.trim().length() > 0) {
            ctx.getHeaders().putSingle(CorrelationIdUtils.HEADER_CORRELATION_ID, correlationId);
        }
    }
}
