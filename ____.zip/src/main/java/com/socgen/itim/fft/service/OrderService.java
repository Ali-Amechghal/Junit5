package com.socgen.itim.fft.service;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;
import com.socgen.itim.fft.domain.Article;
import com.socgen.itim.fft.dto.OrderDTO;
import com.socgen.itim.fft.dto.OrderLineDTO;

import com.socgen.itim.fft.repository.ArticleRepository;
import com.socgen.itim.fft.util.AppUtils;
import org.springframework.stereotype.Service;

import javax.ws.rs.NotFoundException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Service
public class OrderService {

    public static final BigDecimal DEFAULT_PRICE = new BigDecimal("35.00");

    private static AtomicLong compteurOrder = new AtomicLong(1L);

    private ArticleRepository articleRepository;

    public OrderService(ArticleRepository articleRepository) {
        this.articleRepository = articleRepository;
    }

    public BigDecimal simulateMontantCommande(Long articleId, Integer nb) {

        Optional<Article> articleOptional = articleRepository.findById(articleId);
        if (!articleOptional.isPresent()) {
            return null;
        }

        BigDecimal priceArticle = articleOptional.get().getPrice() == null ? DEFAULT_PRICE : articleOptional.get().getPrice();

        BigDecimal nbArticle = BigDecimal.valueOf(nb == null ? 1 : nb);
        return priceArticle.multiply(nbArticle).setScale(2, BigDecimal.ROUND_CEILING);
    }

    public OrderDTO passerOrder(List<OrderLineDTO> lines, SgUserPrincipal sgUserPrincipal) {
        Set<Long> ensIds = lines.stream().map(OrderLineDTO::getIdArticle).collect(Collectors.toSet());


        Map<Long, Article> mapArticle =
                articleRepository.findAllById(ensIds).stream().collect(Collectors.toMap(Article::getId, article -> article));

        if (mapArticle.size() != ensIds.size()) {
            throw new NotFoundException("Tous les articles n'ont pas été trouvés");
        }

        BigDecimal montantTotal = BigDecimal.ZERO;

        for (OrderLineDTO line : lines) {
            Article article = mapArticle.get(line.getIdArticle());
            montantTotal = montantTotal.add((article.getPrice() == null ? DEFAULT_PRICE : article.getPrice())
                    .multiply(BigDecimal.valueOf(line.getNb())));
        }

        OrderDTO order = new OrderDTO()
                .id(compteurOrder.getAndIncrement())
                .date(new Date())
                .customer(AppUtils.buildCompleteName(sgUserPrincipal))
                .addLines(lines)
                .montantTotal(montantTotal.setScale(2, BigDecimal.ROUND_CEILING));

        return order;

    }

}
