package com.socgen.itim.fft.config;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.jvm.GarbageCollectorMetricSet;
import com.codahale.metrics.jvm.MemoryUsageGaugeSet;
import com.ryantenney.metrics.spring.config.annotation.EnableMetrics;
import com.ryantenney.metrics.spring.config.annotation.MetricsConfigurerAdapter;
import com.socgen.dga.idp.jaxrs.commons.ConfigKey;
import com.socgen.dga.slf4j.metrics.Slf4jDgaReporter;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import javax.annotation.PostConstruct;
import java.util.concurrent.TimeUnit;

@Configuration
@EnableMetrics(proxyTargetClass = true)
@DependsOn(ConfigKey.SG_SIGNIN_CACHE_BEAN_NAME) // Le caches SGSIGNIn doit être déjà enregistré dans jmx si on le veut dans JCacheGaugeSet
public class MetricsConfig extends MetricsConfigurerAdapter {
    private static final Logger LOGGER = LoggerFactory.getLogger(MetricsConfig.class);
    private static final Logger LOGGER_METRICS = LoggerFactory.getLogger("metrics");


    private MetricRegistry metricRegistry = new MetricRegistry();

    @Autowired
    private ApplicationProperties applicationProperties;


    @Autowired(required = false)
    private HikariDataSource hikariDataSource;

    @PostConstruct
    private void initMetrics(){
        LOGGER.debug("Enregistrement des gauges JVM");

        metricRegistry.register("jvm.memory", new MemoryUsageGaugeSet());
        metricRegistry.register("garbage", new GarbageCollectorMetricSet());
//        metricRegistry.register("jvm.threads", new ThreadStatesGaugeSet());
//        metricRegistry.register("jvm.files", new FileDescriptorRatioGauge());
//        metricRegistry.register("jvm.buffers", new BufferPoolMetricSet(ManagementFactory.getPlatformMBeanServer()));
//        metricRegistry.register("jvm.attributes", new JvmAttributeGaugeSet());

//        metricRegistry.register("jcache.statistics", new JCacheGaugeSet());


        if (hikariDataSource != null) {
            LOGGER.debug("Monitoring de la datasource");
            hikariDataSource.setMetricRegistry(metricRegistry);
        }

        if (applicationProperties.getMetrics().getLogs().isEnabled()) {
            LOGGER.debug("Initializing du reporting SL4J des metrics");
            final Slf4jDgaReporter reporter = Slf4jDgaReporter.forRegistry(metricRegistry)
                    .outputTo(LOGGER_METRICS)
                    .convertRatesTo(TimeUnit.SECONDS)
                    .convertDurationsTo(TimeUnit.MILLISECONDS)
                    .filter((name, metric) -> !name.startsWith("metrics.jvm.memory.pools"))
                    .build();
            reporter.start(applicationProperties.getMetrics().getLogs().getReportFrequency(), TimeUnit.SECONDS);
            registerReporter(reporter);
        }
    }

    @Override
    @Bean
    public MetricRegistry getMetricRegistry() {
        return metricRegistry;
    }
}
