package com.socgen.itim.fft.listener;

import com.socgen.itim.fft.config.ApplicationProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author X174886
 *
 * Un listener sur le job principal du batch
 *
 */
public class JobCompletionNotificationListener extends JobExecutionListenerSupport {

  @Autowired
  private ApplicationProperties applicationProperties;

  private static final Logger LOGGER = LoggerFactory.getLogger(JobCompletionNotificationListener.class);

  @Override
  public void beforeJob(JobExecution jobExecution) {

    if (jobExecution.getStatus() == BatchStatus.STARTED) {
      LOGGER.info("============ JOB DEMARRE ============....\n");
      LOGGER.info("LANCEMENT DU BATCH AVEC LES PARAMETRES DE CONFIGURATION SUIVANTES : \n {}", applicationProperties.toString());
    }
  }

  @Override
  public void afterJob(JobExecution jobExecution) {
    if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
      LOGGER.info("============ JOB TERMINE ============....\n");
    }
  }
}