package com.socgen.itim.fft.repository;

import com.socgen.itim.fft.domain.Article;
import com.socgen.itim.fft.domain.CrmDfe01;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * DFE repository Example
 */
@Repository
public interface DfeRepository extends JpaRepository<CrmDfe01, Long> {

}

