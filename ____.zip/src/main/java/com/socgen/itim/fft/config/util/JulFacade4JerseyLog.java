package com.socgen.itim.fft.config.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.logging.Level;
import java.util.logging.LogRecord;

/**
 * Une petite facade pour utiliser org.glassfish.jersey.logging.LoggingFeature avec slf4j sans utiliser
 * jul-to-slf4j bridge (qui pose des problèmes de performance : https://www.slf4j.org/legacy.html#jul-to-slf4j)
 * Cette facade log en info quoi qu'il arrive. Note : Attention cette facade ne doit pas être utilisé en prod
 */
public class JulFacade4JerseyLog extends java.util.logging.Logger{

    protected Logger logger;

    public JulFacade4JerseyLog(String name) {
        super(name, null);
        logger = LoggerFactory.getLogger(name);
    }

    @Override
    public boolean isLoggable(Level level) {
        return logger.isInfoEnabled();
    }

    @Override
    public void log(LogRecord record) {
        if (logger.isInfoEnabled()) {
            logger.info(record.getMessage());
        }
    }
}
