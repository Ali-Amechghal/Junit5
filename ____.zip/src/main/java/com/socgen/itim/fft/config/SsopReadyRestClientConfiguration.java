package com.socgen.itim.fft.config;

import com.socgen.itim.fft.config.correlationid.CorrelationIdClientFilter;
import com.socgen.itim.fft.config.ssl.SSLHelper;
import com.socgen.itim.fft.config.util.EnvUtils;
import com.socgen.itim.fft.config.util.JulFacade4JerseyLog;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.module.afterburner.AfterburnerModule;
import org.glassfish.jersey.jackson.internal.jackson.jaxrs.json.JacksonJaxbJsonProvider;
import org.glassfish.jersey.jackson.internal.jackson.jaxrs.json.JacksonJsonProvider;
import org.glassfish.jersey.logging.LoggingFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;

@Configuration
public class SsopReadyRestClientConfiguration
{
    private static final Logger LOGGER = LoggerFactory.getLogger(SsopReadyRestClientConfiguration.class);

    @Autowired
    private SgSigninOAuthClientFilter filterSgSignin;

    @Autowired
    private ApplicationProperties applicationProperties;

    @Autowired
    private Environment env;

    /**
     * Un client REST utilisant sg-sigin client
     */
    @Bean
    @Qualifier("SsopOauthRestClient")
    public Client ssopOauthRestClient()
    {
        ClientBuilder clientBuilder = ClientBuilder.newBuilder()
                .register(createJacksonJsonProvider())
                .register(CorrelationIdClientFilter.class)
                .register(filterSgSignin);

        if (applicationProperties.getClientRest().isDisableSslCheck()) {
            EnvUtils.checkNotEnvProdOrHomologation(env, "app.disable-ssl-check: true");
            clientBuilder.sslContext(SSLHelper.getMockSSLContextForDev());
            clientBuilder.hostnameVerifier((s, sslSession) -> true);
        }


        if (applicationProperties.getClientRest().isEnableLogJerseyClient()) {
            // Les logs de jersey-client (app.rest.enable-log-jax-rs-client: true) sont activées alors que nous sommes
            // en profile de prod. Pour des raisons de sécurité (données, bearer, secret, etc...) ces logs ne peuvent pas
            // être actives en prod. Vérifiez votre configuration. Les logs de jersey-client ne sont pas activées.
            EnvUtils.checkNotEnvProdOrHomologation(env, "app.rest.enable-log-jax-rs-client: true");
            LOGGER.warn("Les logs jersey-client sont activées");
            clientBuilder.register(new LoggingFeature(new JulFacade4JerseyLog("jersey-client")));

        }

        return clientBuilder.build();
    }

    /**
     * On configure ici le mapper jackson pour le client
     */
    private JacksonJsonProvider createJacksonJsonProvider() {
        // On peux ici enregistrer des modules jackson et des conf jackson
        ObjectMapper mapper = new ObjectMapper()
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
                        applicationProperties.getClientRest().isJsonDeserializationFailUnknownProperties())
                .registerModule(new AfterburnerModule());

        return new JacksonJaxbJsonProvider(mapper, JacksonJaxbJsonProvider.DEFAULT_ANNOTATIONS);
    }
    /**
     * Un client REST n'utilisant pas sg-sigin
     */
    @Bean
    @Qualifier("SsopRestClient")
    public Client ssopRestClient()
    {
        return ClientBuilder.newBuilder()
                .register(CorrelationIdClientFilter.class)
                .build();
    }

}
