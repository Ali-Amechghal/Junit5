package com.socgen.itim.fft.config;

import com.socgen.dga.idp.client.SgSignInClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import java.io.IOException;

@Component
@Priority(Priorities.AUTHENTICATION)
public class SgSigninOAuthClientFilter implements ClientRequestFilter
{
    private SgSignInClient sgSignInClient;

    @Autowired
    private ApplicationProperties applicationProperties;

    private String clientId;

    @PostConstruct
    public void initFilter()
    {
        // Create an instance of SgSignInClient
        sgSignInClient = new SgSignInClient(
                applicationProperties.getSgSignIn().getClientId(),
                applicationProperties.getSgSignIn().getClientSecret(),
                applicationProperties.getSgSignIn().getServerUrl());
    }

    @Override
    public void filter(ClientRequestContext requestContext) throws IOException
    {
        // Get a valid access token
        String myToken = sgSignInClient.getAccessToken();

        requestContext.getHeaders().add(HttpHeaders.AUTHORIZATION, myToken);
        requestContext.getHeaders().add("x-ibm-client-id", applicationProperties.getSgSignIn().getClientId());

    }
}
