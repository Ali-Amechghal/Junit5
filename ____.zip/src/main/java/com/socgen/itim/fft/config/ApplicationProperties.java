package com.socgen.itim.fft.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Arrays;

@ConfigurationProperties("app")
public class ApplicationProperties
{
    private final SgSignIn sgSignIn = new SgSignIn();

    private final ClientRest clientRest = new ClientRest();

    private final Metrics metrics = new Metrics();

    private final Swagger swagger = new Swagger();

    private final Async async = new Async();

    private String trigram;

    private boolean enableLogJerseyServer = false;

    public SgSignIn getSgSignIn() {
        return sgSignIn;
    }

    public ClientRest getClientRest() {
        return clientRest;
    }

    public Metrics getMetrics() {
        return metrics;
    }

    public Swagger getSwagger() {
        return swagger;
    }

    public Async getAsync() {
        return async;
    }

    public String getTrigram() {
        return trigram;
    }

    public void setTrigram(String trigram) {
        this.trigram = trigram;
    }

    public boolean isEnableLogJerseyServer() {
        return enableLogJerseyServer;
    }

    public void setEnableLogJerseyServer(boolean enableLogJerseyServer) {
        this.enableLogJerseyServer = enableLogJerseyServer;
    }

    public static class SgSignIn
    {
        private String clientId;

        private String clientSecret;

        private String redirectUrl;

        private String serverUrl;

        private boolean acceptOnlyRequestsFromSSOP = true;

        private boolean enableCors = true;

        private String corsDomain = "*";

        public String getClientId() {
            return clientId;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String getClientSecret() {
            return clientSecret;
        }

        public void setClientSecret(String clientSecret) {
            this.clientSecret = clientSecret;
        }

        public String getRedirectUrl() {
            return redirectUrl;
        }

        public void setRedirectUrl(String redirectUrl) {
            this.redirectUrl = redirectUrl;
        }

        public String getServerUrl() {
            return serverUrl;
        }

        public void setServerUrl(String serverUrl) {
            this.serverUrl = serverUrl;
        }

        public boolean isAcceptOnlyRequestsFromSSOP() {
            return acceptOnlyRequestsFromSSOP;
        }

        public void setAcceptOnlyRequestsFromSSOP(boolean acceptOnlyRequestsFromSSOP) {
            this.acceptOnlyRequestsFromSSOP = acceptOnlyRequestsFromSSOP;
        }

        public boolean isEnableCors() {
            return enableCors;
        }

        public void setEnableCors(boolean enableCors) {
            this.enableCors = enableCors;
        }

        public String getCorsDomain() {
            return corsDomain;
        }

        public void setCorsDomain(String corsDomain) {
            this.corsDomain = corsDomain;
        }
    }

    public static class BacthConfiguration {

        private String inputFiles;

        private String outputFiles;

        public String getInputFiles() {
            return inputFiles;
        }

        public void setInputFiles(String inputFiles) {
            this.inputFiles = inputFiles;
        }

        public String getOutputFiles() {
            return outputFiles;
        }

        public void setOutputFiles(String outputFiles) {
            this.outputFiles = outputFiles;
        }
    }

    public static class ClientRest
    {
        private boolean enableLogJerseyClient = false;

        private boolean disableSslCheck = false;

        private boolean jsonDeserializationFailUnknownProperties = true;

        private String sampleUri;

        public boolean isJsonDeserializationFailUnknownProperties() {
            return jsonDeserializationFailUnknownProperties;
        }

        public void setJsonDeserializationFailUnknownProperties(boolean jsonDeserializationFailUnknownProperties) {
            this.jsonDeserializationFailUnknownProperties = jsonDeserializationFailUnknownProperties;
        }

        public String getSampleUri() {
            return sampleUri;
        }

        public void setSampleUri(String sampleUri) {
            this.sampleUri = sampleUri;
        }

        public boolean isEnableLogJerseyClient() {
            return enableLogJerseyClient;
        }

        public void setEnableLogJerseyClient(boolean enableLogJerseyClient) {
            this.enableLogJerseyClient = enableLogJerseyClient;
        }

        public boolean isDisableSslCheck() {
            return disableSslCheck;
        }

        public void setDisableSslCheck(boolean disableSslCheck) {
            this.disableSslCheck = disableSslCheck;
        }
    }

    public static class Metrics {

        private final Logs logs = new Logs();

        public Logs getLogs() {
            return logs;
        }

        public static class Logs {

            private boolean enabled = false;

            private long reportFrequency = 60;

            public long getReportFrequency() {
                return reportFrequency;
            }

            public void setReportFrequency(int reportFrequency) {
                this.reportFrequency = reportFrequency;
            }

            public boolean isEnabled() {
                return enabled;
            }

            public void setEnabled(boolean enabled) {
                this.enabled = enabled;
            }
        }


    }

    public static class Swagger {

        private String title;

        private String description;

        private String version;

        private String host;

        private String termsOfServiceUrl;

        private String contactName;

        private String contactUrl;

        private String contactEmail;

        private String license;

        private String licenseUrl;

        private String[] schemes;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getHost() {
            return host;
        }

        public void setHost(String host) {
            this.host = host;
        }

        public String getTermsOfServiceUrl() {
            return termsOfServiceUrl;
        }

        public void setTermsOfServiceUrl(String termsOfServiceUrl) {
            this.termsOfServiceUrl = termsOfServiceUrl;
        }

        public String getContactName() {
            return contactName;
        }

        public void setContactName(String contactName) {
            this.contactName = contactName;
        }

        public String getContactUrl() {
            return contactUrl;
        }

        public void setContactUrl(String contactUrl) {
            this.contactUrl = contactUrl;
        }

        public String getContactEmail() {
            return contactEmail;
        }

        public void setContactEmail(String contactEmail) {
            this.contactEmail = contactEmail;
        }

        public String getLicense() {
            return license;
        }

        public void setLicense(String license) {
            this.license = license;
        }

        public String getLicenseUrl() {
            return licenseUrl;
        }

        public void setLicenseUrl(String licenseUrl) {
            this.licenseUrl = licenseUrl;
        }

        public String[] getSchemes() {
            return schemes;
        }

        public void setSchemes(String[] schemes) {
            this.schemes = schemes;
        }

        @Override
        public String toString() {
            return "Swagger{" +
                "title = '" + title + '\'' +
                ", \ndescription = '" + description + '\'' +
                ", \nversion = '" + version + '\'' +
                ", \nhost = '" + host + '\'' +
                ", \ntermsOfServiceUrl = '" + termsOfServiceUrl + '\'' +
                ", \ncontactName = '" + contactName + '\'' +
                ", \ncontactUrl = '" + contactUrl + '\'' +
                ", \ncontactEmail = '" + contactEmail + '\'' +
                ", \nlicense = '" + license + '\'' +
                ", \nlicenseUrl = '" + licenseUrl + '\'' +
                ", \nschemes = " + Arrays.toString(schemes) +
                '}';
        }
    }

    public static class Async {

        private int corePoolSize = 2;

        private int maxPoolSize = 50;

        private int queueCapacity = 10000;

        public int getCorePoolSize() {
            return corePoolSize;
        }

        public void setCorePoolSize(int corePoolSize) {
            this.corePoolSize = corePoolSize;
        }

        public int getMaxPoolSize() {
            return maxPoolSize;
        }

        public void setMaxPoolSize(int maxPoolSize) {
            this.maxPoolSize = maxPoolSize;
        }

        public int getQueueCapacity() {
            return queueCapacity;
        }

        public void setQueueCapacity(int queueCapacity) {
            this.queueCapacity = queueCapacity;
        }

        @Override
        public String toString() {
            return "Async{" +
                "corePoolSize = " + corePoolSize +
                ", \nmaxPoolSize = " + maxPoolSize +
                ", \nqueueCapacity = " + queueCapacity +
                '}';
        }
    }

    @Override
    public String toString() {
        return "ApplicationProperties{" +
            "\nsgSignIn = " + sgSignIn +
            ", \nclientRest = " + clientRest +
            ", \nmetrics = " + metrics +
            ", \nswagger = " + swagger +
            ", \nasync = " + async +
            ", \ntrigram = '" + trigram + '\'' +
            ", \nenableLogJerseyServer = " + enableLogJerseyServer +
            '}';
    }
}
