package com.socgen.itim.fft.config.util;

import com.socgen.itim.fft.config.ConfigConstants;
import com.socgen.itim.fft.exception.ApplicationException;
import org.springframework.core.env.Environment;

public class EnvUtils {
    public static void checkNotEnvProdOrHomologation(Environment env, String textElementNotPossible) {
        if(env.acceptsProfiles(
                ConfigConstants.SPRING_PROFILE_PROD,
                ConfigConstants.SPRING_PROFILE_HOT,
                ConfigConstants.SPRING_PROFILE_HOB)
                || !env.acceptsProfiles(
                ConfigConstants.SPRING_PROFILE_LOCAL,
                ConfigConstants.SPRING_PROFILE_DEV,
                ConfigConstants.SPRING_PROFILE_INT,
                ConfigConstants.SPRING_PROFILE_TEST,
                ConfigConstants.SPRING_PROFILE_TESTINT)) {
            throw new ApplicationException("Cette configuration n'est possible qu'en dev ou integration," +
                    "pas en environnement de prod ou d'homologation : " + textElementNotPossible);
        }
    }
}
