package com.socgen.itim.fft.integration.rest;

import com.codahale.metrics.annotation.Timed;
import com.socgen.itim.fft.config.ApplicationProperties;
import com.socgen.itim.fft.rest.sample.models.Sample;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Optional;

/**
 * Sample REST client
 */
@Service
public class SampleService {

    @Autowired
    ApplicationProperties applicationProperties;

    @Autowired
    @Qualifier("SsopOauthRestClient")
    private Client restClient;

    private WebTarget resourceTarget;

    @PostConstruct
    private void initService() {
        resourceTarget = restClient.target(applicationProperties.getClientRest().getSampleUri());
    }

    public Optional<Sample> getSampleParId(Long sampleId) {
        return Optional.ofNullable(
                resourceTarget
                        .path("/samples/{sampleId}")
                        .resolveTemplate("sampleId", sampleId)
                        .request()
                        .buildGet().invoke(Sample.class)
        );
    }

    @Timed
    public Optional<List<Sample>> geAllSamples() {
        return Optional.ofNullable(
                resourceTarget
                        .path("/samples")
                        .request().get(Response.class)
                        .readEntity(new GenericType<List<Sample>>() {})
        );
    }
}
