package com.socgen.itim.fft.config;

import com.fasterxml.jackson.databind.JsonMappingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

public class JsonMappingExceptionMapper implements ExceptionMapper<JsonMappingException>
{
    private static final Logger LOGGER = LoggerFactory.getLogger(JsonMappingExceptionMapper.class);

    @Produces("application/json")
    public Response toResponse(JsonMappingException exception)
    {
        LOGGER.error("Failure in jackson mapping", exception);
        return Response.status(Response.Status.BAD_REQUEST).build();
    }
}
