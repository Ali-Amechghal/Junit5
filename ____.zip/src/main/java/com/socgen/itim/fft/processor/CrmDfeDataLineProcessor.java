package com.socgen.itim.fft.processor;

import com.socgen.itim.fft.domain.CrmDfe01;
import com.socgen.itim.fft.dto.dfe.CrmDfeHeader;
import com.socgen.itim.fft.listener.JobCompletionNotificationListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

/**
 * @author X174886
 * <p>
 * Processeur de données DFE
 * <p>
 * DFE DTO --> Entity
 */
public class CrmDfeDataLineProcessor implements ItemProcessor<CrmDfeHeader, CrmDfe01> {

    private static final Logger LOGGER = LoggerFactory.getLogger(JobCompletionNotificationListener.class);

    @Override
    public CrmDfe01 process(CrmDfeHeader sampleCrmDfeHeader) {
        LOGGER.info("Processing data {}", sampleCrmDfeHeader.toString());
        return CrmDfe01.builder().idTiers(sampleCrmDfeHeader.getIdTiers()).message("OK").build();

    }
}
