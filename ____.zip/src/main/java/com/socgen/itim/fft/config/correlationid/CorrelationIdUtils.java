package com.socgen.itim.fft.config.correlationid;

import org.slf4j.MDC;

import java.util.Random;

/**
 * Inspiré par : https://blog.bandwidth.com/a-recipe-for-adding-correlation-ids-in-java-microservices/
 */
public class CorrelationIdUtils {
    public static final String HEADER_CORRELATION_ID = "X-Global-Transaction-ID";

    public static final String MDC_NAME_CORRELATION_ID = "Global-Transaction-ID";

    private static Random random = new Random();

    public static final int MAX_ID_SIZE = 50;

    private static final ThreadLocal<String> threadCorrelationId = new ThreadLocal<>();

    public static String getCorrelationId() {
        return threadCorrelationId.get();
    }

    public static String addOrCreateCorrelationId(String correlationIdSource) {
        String correlationId = verifyOrCreateId(correlationIdSource);
        threadCorrelationId.set(correlationId);
        MDC.put(MDC_NAME_CORRELATION_ID, correlationId);
        return correlationId;
    }

    public static void removeCorrelationId(){
        threadCorrelationId.remove();
        MDC.remove(MDC_NAME_CORRELATION_ID);
    }

    private static String verifyOrCreateId(String correlationId)
    {
        if(correlationId == null || correlationId.trim().length() == 0)
        {
            correlationId = generateCorrelationId();
        }
        //prevent on-purpose or accidental DOS attack that
        // fills logs with long correlation id provided by client
        else if (correlationId.length() > MAX_ID_SIZE)
        {
            correlationId = correlationId.substring(0, MAX_ID_SIZE);
        }
        return correlationId;
    }

    private static String generateCorrelationId()
    {
        final String tabChars = "0123456789abcdefghijklmnopqrstuvwxyz";
        final long divisor = tabChars.length();

        long n = random.nextLong();

        StringBuilder builder = new StringBuilder();

        long index = Long.remainderUnsigned(n, divisor);
        builder.append(tabChars.charAt((int) index));
        n = Long.divideUnsigned(n, divisor);
        //now the long is unsigned, can just do regular math ops
        while (n > 0)
        {
            builder.append(tabChars.charAt((int) (n % divisor)));
            n /= divisor;
        }
        return builder.toString();
    }
}