package com.socgen.itim.fft.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public class OrderDTO {
    private Long id;
    private String customer;
    private Date date;
    private List<OrderLineDTO> lines = new ArrayList<>();
    private BigDecimal montantTotal;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public List<OrderLineDTO> getLines() {
        return lines;
    }

    public void setLines(List<OrderLineDTO> lines) {
        this.lines = lines;
    }

    public BigDecimal getMontantTotal() {
        return montantTotal;
    }

    public void setMontantTotal(BigDecimal montantTotal) {
        this.montantTotal = montantTotal;
    }

    public OrderDTO id(final Long id) {
        this.id = id;
        return this;
    }

    public OrderDTO customer(final String customer) {
        this.customer = customer;
        return this;
    }

    public OrderDTO date(final Date date) {
        this.date = date;
        return this;
    }

    public OrderDTO lines(final List<OrderLineDTO> lines) {
        this.lines = lines;
        return this;
    }

    public OrderDTO montantTotal(final BigDecimal montantTotal) {
        this.montantTotal = montantTotal;
        return this;
    }

    public OrderDTO addLine(final OrderLineDTO orderLineDTO) {
        this.lines.add(orderLineDTO);
        return this;
    }

    public OrderDTO addLines(final Collection<OrderLineDTO> colOrderLineDTO) {
        this.lines.addAll(colOrderLineDTO);
        return this;
    }
}
