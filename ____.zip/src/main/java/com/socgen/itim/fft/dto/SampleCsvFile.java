package com.socgen.itim.fft.dto;

public class SampleCsvFile {
}
