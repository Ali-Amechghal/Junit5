package com.socgen.itim.fft.enumeration;

import com.socgen.itim.fft.dto.dfe.SampleCrmDfe01;

/**
 * @author X174886
 * <p>
 * La liste des comptes rendu DFE
 * <p>
 * A compléter
 */
public enum CrmDfeEnum {

    IBFT01(SampleCrmDfe01.class);

    private Class clazz;

    CrmDfeEnum(Class clazz) {
        this.clazz = clazz;
    }

    public Class getClazz() {
        return clazz;
    }

    public static Class getClass(String clazz, boolean isPattern) {
        if (isPattern) {
            return CrmDfeEnum.valueOf(clazz.substring(0, clazz.length() - 1)).getClazz();
        } else {
            return CrmDfeEnum.valueOf(clazz).getClazz();
        }

    }
}
