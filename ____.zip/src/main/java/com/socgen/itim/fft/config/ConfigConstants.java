package com.socgen.itim.fft.config;

public class ConfigConstants {
    public static final String SPRING_PROFILE_LOCAL = "local";
    public static final String SPRING_PROFILE_DEV = "dev";
    public static final String SPRING_PROFILE_INT = "int";
    public static final String SPRING_PROFILE_HOB = "hob";
    public static final String SPRING_PROFILE_HOT = "hot";
    public static final String SPRING_PROFILE_PROD = "prod";
    public static final String SPRING_PROFILE_TEST = "test";
    public static final String SPRING_PROFILE_TESTINT = "testint";
    public static final String SPRING_PROFILE_NO_LIQUIBASE = "no-liquibase";
}
