/**
 * Async helpers.
 */
package com.socgen.itim.fft.config.async;