package com.socgen.itim.fft.config;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.fasterxml.jackson.datatype.hibernate5.Hibernate5Module;

import com.fasterxml.jackson.module.afterburner.AfterburnerModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

@Configuration
public class JacksonContainerConfig
{
    @Autowired
    private ObjectMapper objectMapper;

    @PostConstruct
    private void init()
    {
        
        Hibernate5Module hibernate5Module = new Hibernate5Module();
        hibernate5Module.enable(Hibernate5Module.Feature.FORCE_LAZY_LOADING);
        this.objectMapper.registerModule(hibernate5Module);
        
        this.objectMapper.registerModule(new AfterburnerModule());

    }
}
