package com.socgen.itim.fft.dto;

import javax.validation.constraints.NotNull;

public class OrderLineDTO {

    @NotNull
    private Long idArticle;

    @NotNull
    private Integer nb;

    public Long getIdArticle() {
        return idArticle;
    }

    public void setIdArticle(Long idArticle) {
        this.idArticle = idArticle;
    }

    public Integer getNb() {
        return nb;
    }

    public void setNb(Integer nb) {
        this.nb = nb;
    }

    public OrderLineDTO idArticle(final Long idArticle) {
        this.idArticle = idArticle;
        return this;
    }

    public OrderLineDTO nb(final Integer nb) {
        this.nb = nb;
        return this;
    }


}
