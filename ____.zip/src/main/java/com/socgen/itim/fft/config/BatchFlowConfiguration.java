package com.socgen.itim.fft.config;

import com.socgen.itim.fft.domain.CrmDfe01;
import com.socgen.itim.fft.dto.dfe.CrmDfeHeader;
import com.socgen.itim.fft.listener.JobCompletionNotificationListener;
import com.socgen.itim.fft.mapper.CrmDfeFieldSetMapper;
import com.socgen.itim.fft.mapper.DfeLineMapper;
import com.socgen.itim.fft.mapper.DfeLineTokenizer;
import com.socgen.itim.fft.processor.CrmDfeDataLineProcessor;
import com.socgen.itim.fft.processor.SkipPolicyProcessor;
import com.socgen.itim.fft.reader.DfeFileReader;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.file.transform.PatternMatchingCompositeLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.task.configuration.EnableTask;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author X174886
 * <p>
 * Configuration et automatisation du batch
 * <p>
 * A modifier selon le besoin
 */
@Configuration
@EnableTask
@EnableBatchProcessing
@Profile("local")
public class BatchFlowConfiguration {
    /**
     * le factory d'un job batch
     */
    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    /**
     * le factory des steps batch
     */
    @Autowired
    private StepBuilderFactory stepBuilderFactory;


    @Bean
    Job crmTiersJob(ItemReader<CrmDfeHeader> fileItemReader, @Qualifier("fileWriter") ItemWriter<CrmDfe01> itemWriter) {
        return jobBuilderFactory.get("crmTiersJob")
                .incrementer(new RunIdIncrementer())
                .listener(jobExecutionListenerSupport())
                .start(fileReadStep(fileItemReader, itemWriter))
                .build();
    }

    @Bean
    public Step fileReadStep(ItemReader<CrmDfeHeader> fileItemReader, @Qualifier("fileWriter") ItemWriter<CrmDfe01> itemWriter) {
        return stepBuilderFactory.get("fileReadStep")
                .<CrmDfeHeader, CrmDfe01>chunk(2)
                .reader(fileItemReader)
                .processor(crmTiersFileProcessor())
                .writer(itemWriter)
                .taskExecutor(threadPoolTaskExecutor())
                .throttleLimit(5)
                .build();
    }

    @Bean
    public ItemReader<CrmDfeHeader> fileItemReader(@Value("${input}") Resource resource) {
        final DfeFileReader<CrmDfeHeader> itemReader = new DfeFileReader<>();
        itemReader.setResource(resource.exists() ? resource : new ClassPathResource(resource.getFilename()));
        itemReader.setResource(resource);
        itemReader.setLineMapper(lineMapper());
        itemReader.setEncoding("UTF-8");
        return itemReader;

    }

    @Bean
    public LineMapper<CrmDfeHeader> lineMapper() {
        DfeLineMapper<CrmDfeHeader> dfeLineMapper = new DfeLineMapper<>();
        dfeLineMapper.setLineTokenizer(fixedFileDescriptor());
        dfeLineMapper.setFieldSetMapper(fieldSetMapper());
        return dfeLineMapper;

    }

    @Bean
    public LineTokenizer fixedFileDescriptor() {
        PatternMatchingCompositeLineTokenizer dfePatternMatchingLineTokenizer = new PatternMatchingCompositeLineTokenizer();
        List<Integer> dfeCrmId = Arrays.asList(6, 1, 4, 8, 2, 5, 90, 20, 7, 1, 3, 3, 1, 1, 1, 1, 1, 1, 1, 1);
        Map<String, List<Integer>> attributes = new HashMap<>();
        attributes.put("IBFT01*", dfeCrmId);
        dfePatternMatchingLineTokenizer.setTokenizers(prepareTokenizers(attributes));
        return dfePatternMatchingLineTokenizer;
    }

    /**
     * Prepare la liste des tokenizers pour matcher les lignes DFE
     *
     * @param attributes
     * @return
     */
    private static HashMap<String, LineTokenizer> prepareTokenizers(Map<String, List<Integer>> attributes) {
        HashMap<String, LineTokenizer> matchers = new HashMap<>();
        attributes.forEach((idCrm, ranges) -> {
            DfeLineTokenizer dfeLineTokenizer = new DfeLineTokenizer();
            LineTokenizer tokenizer = dfeLineTokenizer.tokenizeDfeLine(idCrm, ranges);
            matchers.put(idCrm, tokenizer);
        });
        return matchers;
    }

    @Bean
    FieldSetMapper fieldSetMapper() {
        return new CrmDfeFieldSetMapper();
    }

    @Bean
    public ThreadPoolTaskExecutor threadPoolTaskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setCorePoolSize(5);
        return taskExecutor;
    }

    @Bean
    public SkipPolicy skipPolicyBatch() {
        return new SkipPolicyProcessor();
    }

    @Bean
    ItemProcessor<CrmDfeHeader, CrmDfe01> crmTiersFileProcessor() {
        return new CrmDfeDataLineProcessor();
    }

    @Bean
    JobExecutionListenerSupport jobExecutionListenerSupport() {
        return new JobCompletionNotificationListener();
    }
}
