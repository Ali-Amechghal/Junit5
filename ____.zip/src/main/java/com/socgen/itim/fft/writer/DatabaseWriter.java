package com.socgen.itim.fft.writer;

import com.socgen.itim.fft.domain.CrmDfe01;
import com.socgen.itim.fft.repository.DfeRepository;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author X174886
 * <p>
 * Ecriture dans un fichier texte
 */
@Configuration
public class DatabaseWriter {


    //Ajouter ici les writer database
    /**
     * Data base Writer
     * @param dfeRepository
     * @return RepositoryItemWriter
     */
    @Bean(name = "dfeDatabaseWriter")
    RepositoryItemWriter<CrmDfe01> dfeRepositoryItemWriter(DfeRepository dfeRepository) {
        RepositoryItemWriter<CrmDfe01> repositoryItemWriter = new RepositoryItemWriter<>();
        repositoryItemWriter.setRepository(dfeRepository);
        repositoryItemWriter.setMethodName("save");
        return repositoryItemWriter;
    }


}
