package com.socgen.itim.fft.util;

import com.socgen.dga.idp.jaxrs.commons.SgUserPrincipal;

public class AppUtils {
    public static final String PREFIX_APP = "app:";
    public static final String PREFIX_USER = "user:";


    public static String buildCompleteName(SgUserPrincipal sgUserPrincipal) {
        if (sgUserPrincipal == null) {
            return null;
        }
        if(sgUserPrincipal.isEndUser()) {
            return PREFIX_USER + sgUserPrincipal.getCurrentUser().getUserId();
        }
        else {
            return PREFIX_APP + sgUserPrincipal.getCurrentApp().getAppId();
        }
    }

}
